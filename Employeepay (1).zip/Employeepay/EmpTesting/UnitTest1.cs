using NUnit.Framework;
using Emplib;



namespace EmpTesting
{

    public class Tests
    {
        Empcls ob = new Empcls();



        [SetUp]
        public void Setup()
        {
        }

        [Test]

        public void login()
        {
            int a = ob.Login( 1,"Mahesh", "india");

            Assert.AreEqual(1, a);
        }
        [Test]

        public void login1()
        {
            int a = ob.Login(0, "raju@gmail.com", "raju");

            Assert.AreEqual(1, a);
        }




        [Test]
        public void Test1()
        {
            var item = ob.DisplayEmp();
            Assert.AreEqual(4,item.Count);
        }

        [Test]
        public void Test2()
        {
            var item = ob.Viewschedule(772);
            Assert.AreEqual(1,item.Count);
        }

        [Test]
        public void Test3()
        {
            var item = ob.Display(760);
            Assert.AreEqual(1, item.Count);
        }
        [Test]
        public void Test4()
        {
            var item = ob.Leavecheck(536);
            Assert.AreEqual(1, item.Count);
        }
      
        [Test]
        public void Test5()
        {
            var item = ob.Empcheck("raju@gmail.com");
            Assert.AreEqual(1, item);
        }

    }
}