﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emplib
{
    public class Empcls
    {
        DbfinanceContext EmpObject = new DbfinanceContext();

        public object ModelState { get; private set; }
        public int add(msalary s)
        {

            EmpObject.msalaries.Add(s);
            int i = EmpObject.SaveChanges();
            return i;

        }
        public List<msalary> Display(int id)
        {
            var res = (from t in EmpObject.msalaries
                       where t.employeeid == id
                       select t).ToList();
            return res;

        }
        public List<register> DisplayEmp()
        {
            var result = EmpObject.registers.ToList();
            return result;

        }
        public int Apply(leave l)
        {

            EmpObject.leaves.Add(l);
            int i = EmpObject.SaveChanges();
            return i;

        }
        public int employeeid(string user)
        {

            var res = (from t in EmpObject.registers
                       where t.email == user
                       select t.employeeid).FirstOrDefault();
            return res;

        }
        public List<leave> DisplayLeave()
        {
            var result = (from t in EmpObject.leaves where t.status == null select t).ToList();
            return result;

        }
        public int Empregister(register r)
        {

            EmpObject.registers.Add(r);
            int res = EmpObject.SaveChanges();
            return res;

        }


        public int Emplogin(string username, string password)
        {
            var res = (from t in EmpObject.registers
                       where t.email == username & t.passwords == password
                       select t).Count();

            return res;

        }
        public int Leavebutton(int employeeid, int leaveid, String Button)
        {
            var result = (from t in EmpObject.leaves
                          where t.leaveid == leaveid && t.employeeid == employeeid
                          select t).FirstOrDefault();
            result.status = Button;

            int res = EmpObject.SaveChanges();

            return res;
        }
        public int addemp(register r)
        {

            EmpObject.registers.Add(r);
            int i = EmpObject.SaveChanges();
            return i;

        }


        public int Empcheck(int Employeeid)
        {
            var res = (from t in EmpObject.registers
                       where t.employeeid==Employeeid
                       select t).Count();
            return res;
        }


        public int Login(int adm, string uname, string pwd)
        {
            if (adm == 0)
            {

                var res = (from t in EmpObject.registers
                           where t.email == uname & t.passwords == pwd
                           select t).Count();

                return res;

            }
           
            else if (adm ==1)
            {
                if (uname == "Mahesh" && pwd == "india")
                {
                    var res = 1;
                    return res;
                }
                else
                {
                    var res = 0;
                    return res;

                }


            }
            else
            {
                var res = 0;
                return res;

            }
        }
        public int wrk(wrkschedule w)
        {
            EmpObject.wrkschedules.Add(w);

            int i = EmpObject.SaveChanges();
            return i;

        }
        public List<register> displaySearch(string tofind)
        {

            List<register> res = (from t in EmpObject.registers
                               where t.email.Contains(tofind)
                               select t).ToList();
            return res;
        }


        public int Empcheck(string mail)
        {
            var res = (from t in EmpObject.registers
                       where t.email==mail 
                       select t).Count();
            return res;
        }
        public List<leave> Leavecheck(int id)
        {
            var res = (from t in EmpObject.leaves
                       where t.employeeid == id
                       select t).ToList();
            return res;

        }
        public List<wrkschedule> Viewschedule(int id)
        {
            var res = (from t in EmpObject.wrkschedules
                       where t.employeeid == id
                       && t.todate > DateTime.Today
                       select t).ToList();
            return res;

        }
        public List<register> EmpProfile(string user)
        {
            var result = (from t in EmpObject.registers
                          where t.email == user
                          select t).ToList();
            return result;

        }
        //public List<attendence> DisplayAttend()
        //{
        //    var result = EmpObject.attendences.ToList();
        //    return result;

        //}
        public attend displayattend()
        {
            attend ob = new attend();
            ob.register = EmpObject.registers.ToList();
            ob.attendecee = EmpObject.attendecees.ToList();
            return ob;
        }
        public class attend
        {
            public List<register> register { get; set; }
            public List<attendecee> attendecee { get; set; }

        }

        public int Empattend(attendecee a)
        {

            EmpObject.attendecees.Add(a);
            int res = EmpObject.SaveChanges();
            return res;

        }
        public List<register> Attendsearch(string tofind1)
        {

            List<register> res = (from t in EmpObject.registers
                                  where t.email.Contains(tofind1)
                                  select t).ToList();
            return res;
        }


    }
}

