﻿namespace Emplib
{
    public class Class1
    {

    }
}