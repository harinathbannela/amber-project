﻿using Microsoft.AspNetCore.Mvc;
using Emplib;

namespace Employeepay.Controllers
{
    public class AdminController : Controller
    {
        Empcls ob = new Empcls();
        DbfinanceContext EmpObject = new DbfinanceContext();




        public IActionResult Index()
        {
            return View();
        }
        public ActionResult _Layout1()
        {
            ViewData["username"] = HttpContext.Session.GetString("user");
            return View();

        }

        public ActionResult Home()
        {
           
                //Employees count
                var count = (from t in EmpObject.registers
                             select t.employeeid).Count();
                ViewData["Empcount"] = count;

                //Leaves count
                
            var ccount = (from t in EmpObject.leaves
                          select t.leaveid).Count();
            ViewData["TLeavecount"] = ccount;

            var bcount = (from t in EmpObject.wrkschedules
                          select t.sno).Count();
            ViewData["Wrkcount"] = bcount;


            var acount = (from t in EmpObject.msalaries
                          select t.msalaryid).Count();
            ViewData["Salarycount"] = acount;




            return View();

            }

         
        public ActionResult Employees()
        {
            var result = ob.DisplayEmp();
            return View(result);

        }



        [HttpGet]
        public ActionResult Addsalary()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Addsalary(msalary s)
        {


            if (ModelState.IsValid)
            {

                try
                {

                    int i = ob.add(s);
                    if (i > 0)
                    {
                        ViewData["addsalary"] = "Salary Added Successfully";
                    }
                }

                catch (Exception error)
                {
                    ViewData["invalid"] = "EmployeeID Not Exists";
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult Leave()
        {
            var result = ob.DisplayLeave();
            return View(result);

        }
        [HttpPost]
        public ActionResult Leave(int employeeid, int leaveid, String Button)

        {
            var i = ob.Leavebutton(employeeid, leaveid, Button);
            if (i > 0)
            {

                return RedirectToAction("Leave");

            }
            else
            {
                ViewData["Approve"] = "invalid result";
                return View();
            }

        }
        [HttpGet]
        public ActionResult AddEmployee()
        {

            return View();
        }
        [HttpPost]
        public ActionResult AddEmployee(register r)
        {

            if (ModelState.IsValid)
            {



                try
                {






                    var i = ob.addemp(r);
                if (i > 0)
                {
                    ViewData["add"] = "Employee Added Successfully";
                }
                }
                catch (Exception error)
                {
                    ViewData["exists"] = "Employee Already Exists";
                }
            }




            return View();
        }




     
        [HttpGet]
       
        public ActionResult UpdateEmp(int myempid)
        {
            var result = EmpObject.registers.ToList().Find(c => c.employeeid == myempid);

            return View(result);

        }
    
     
    
        [HttpPut][HttpPost]
     
        public ActionResult UpdateEmp(register r)
        {
            if (ModelState.IsValid)
            {



                try
                {



                    EmpObject.registers.Update(r);
            int i = EmpObject.SaveChanges();

            if (i > 0)
            {
                ViewData["update"] = "Update Successfully";
            }
                }
                catch (Exception error)
                {
                    ViewData["invalid"] = " Cannot update.Employee Email or Phone is Already used for Another Employee";
                }
            }
            return View();
        }
        [HttpGet]
        public ActionResult DeleteEmp(int employeeid)
        {
            

                var result = EmpObject.registers.ToList().Find(c => c.employeeid==employeeid);
           
                return View(result);
            }

        
        [HttpDelete][HttpPost]
        public ActionResult DeleteEmp(register r, int employeeid)
        {
           



                    var result = EmpObject.registers.ToList().Find(c => c.employeeid == employeeid);
                    EmpObject.registers.Remove(result);
                    int i = EmpObject.SaveChanges();
                    

                     ViewData["delete"] = "Sucessfully deleted!!";
                    
               
            
            return View();

        }
        [HttpGet]
        public ActionResult Schedule()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Schedule(wrkschedule w)
        {
            if (ModelState.IsValid)
            {



                try
            {
                   

                    
                        int i = ob.wrk(w);
                    
                if (i > 0)
                {
                    ViewData["assign"] = "Work Assigned";
                }
            }
            catch (Exception error)
            {
                ViewData["invalid"] = "Employee Not Exists";
            }
        }
            return View();
        }
        public ActionResult Logout()
        {
            HttpContext.Session.Remove("uid");
            return View();
        }

        public ActionResult Search(string tofind)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    if (tofind != "" && tofind != null)
                    {
                        List<register> res = ob.displaySearch(tofind);
                        return View(res);
                    }

                }
                catch (Exception error)
                {
                    ViewData["search"] = "No Result Found";
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult Updateattendence(int myempid2)
        {
            var result = EmpObject.attendecees.ToList().Find(c => c.employeeid == myempid2);

            return View(result);

        }
        [HttpPost]
        public ActionResult UpdateAttendence(attendecee a)
        {
            EmpObject.attendecees.Update(a);
            int i = EmpObject.SaveChanges();

            if (i > 0)
            {
                ViewData["a"] = "Update Successfully";
            }

            return View();
        }
        public ActionResult Attendence()
        {
            var res = ob.displayattend();



            var result = from t in res.register
                         from t1 in res.attendecee
                         where t.employeeid == t1.employeeid
                        
                         select new { register = t, attendecee = t1 };
            return View(result);

        }
        public ActionResult Asearch(string tofind1)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    if (tofind1 != "" && tofind1 != null)
                    {
                        List<register> res = ob.Attendsearch(tofind1);
                       

                        return View(res);
                    }

                }
                catch (Exception error)
                {
                    Console.WriteLine(error.StackTrace);
                }
            }
            return View();
        }
        public ActionResult Aprofile()

        {

            ViewData["username"] = HttpContext.Session.GetString("user");

            return View();
        }
        //For Testing
        public string mytext()
        {
            return "Hello world";
        }
    }



}











    

