﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Emplib;

namespace Employeepay.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PayApiController : ControllerBase
    {
        DbfinanceContext dc = new DbfinanceContext();
        // GET: api/<PayApiController>
        [HttpGet]
        public IEnumerable<register> Get()
        {
            var res = dc.registers;
            return res;
        }


        // GET api/<PayApiController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<PayApiController>
        [HttpPost]
        public register Post(register s)
        {
            dc.registers.Add(s);
            int i = dc.SaveChanges();
            if (i > 0)
            {
                return s;
            }
            else
            {
                return null;
            }
        }

        // PUT api/<PayApiController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<PayApiController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {

        }
    }
}
















    

