﻿using Microsoft.AspNetCore.Mvc;
using Emplib;

namespace Employeepay.Controllers
{
    public class EmpController : Controller
    {
        Empcls ob = new Empcls();
        DbfinanceContext EmpObject = new DbfinanceContext();

        public IActionResult Index()
        {
            return View();
        }
        public ActionResult _Layout()
        {
            ViewData["username"] = HttpContext.Session.GetString("uid");
            return View();

        }
        public ActionResult Viewsalary()
        {
            string user = HttpContext.Session.GetString("uid");
            int id = ob.employeeid(user);
            var result = ob.Display(id);
            return View(result);
        }
        public ActionResult ViewSchedule()
        {
            string user = HttpContext.Session.GetString("uid");
            int id = ob.employeeid(user);
            var result = ob.Viewschedule(id);
            return View(result);
        }





        public ActionResult Home()
        {
            ViewData["username"] = HttpContext.Session.GetString("uid");
            return View();
        }

        [HttpGet]
        public ActionResult LeaveApply()
        {

            return View();
        }
        [HttpPost]
        public ActionResult LeaveApply(leave l)
        {

            if (HttpContext.Session.GetString("uid") == null)
            {
                return RedirectToAction("Login");
            }
            else
            {

                string user = HttpContext.Session.GetString("uid");
                int id = ob.employeeid(user);

                l.employeeid = id;

                int i = ob.Apply(l);
                if (i > 0)
                {
                    ViewData["a"] = "Leave Applied Successfully";
                }
                else
                {
                    ViewData["a"] = "Try again";
                }
                return View();
            }
        }


        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(register r)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    var i = ob.Empregister(r);

                    if (i > 0)
                    {
                        ViewData["a"] = "User created Successfully";
                    }

                }
                catch (Exception error)
                {
                    ViewData["a"] = "User already existed";
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {

            return View();
        }

        [HttpPost]
        public ActionResult Login(int adm, string uname, string pwd)
        {




            var res = ob.Login(adm, uname, pwd);
            if (res > 0 && adm == 0)
            {
                HttpContext.Session.SetString("uid", uname);

                return RedirectToAction("Home");

                //ViewData["v"]= HttpContext.Session.GetString("user");
            }




            else if (res > 0 && adm == 1)
            {
                HttpContext.Session.SetString("user", uname);
                return RedirectToAction("Home", "Admin");
            }
            else
            {
                ViewData["a"] = "Invalid username or password";
                return View();
            }

        }








        public ActionResult Logout()
        {
            HttpContext.Session.Remove("uid");
            return View();
        }

        public ActionResult Status()
        {
            string user = HttpContext.Session.GetString("uid");
            int id = ob.employeeid(user);
            var result = ob.Leavecheck(id);
            return View(result);


        }
        public ActionResult Profile()
        {
            string user = HttpContext.Session.GetString("uid");

            var result = ob.EmpProfile(user);
            return View(result);



        }
        [HttpGet]
        public ActionResult DetailsUpdate(int myempid1)
        {
            var result = EmpObject.registers.ToList().Find(c => c.employeeid == myempid1);

            return View(result);

        }
        [HttpPost]
        public ActionResult DetailsUpdate(register r)
        {
            EmpObject.registers.Update(r);
            int i = EmpObject.SaveChanges();

            if (i > 0)
            {
                ViewData["a"] = "Update Successfully";
            }

            return View();
        }
        [HttpGet]
        public ActionResult Attend()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Attend(attendecee a)
        {

            string user = HttpContext.Session.GetString("uid");
            int id = ob.employeeid(user);

            a.employeeid = id;
            a.mail = user;
            a.pdate = DateTime.Today;
            a.astatus = "Present";
            if (ModelState.IsValid)
            {
                try
                {


                    var result = ob.Empattend(a);
                    if (result > 0)
                    {
                        ViewData["a"] = "Attendece Submitted Successfully";
                    }
                }
                catch (Exception e)
                {
                    ViewData["a"] = "Attendence Already Marked Today";
                }
            }
                return View();
            }

        
    }
}
                
               
                
            
               
            
       



    

